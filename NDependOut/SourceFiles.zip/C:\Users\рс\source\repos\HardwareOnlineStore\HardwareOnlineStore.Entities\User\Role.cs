﻿namespace HardwareOnlineStore.Entities.User;

public enum Role
{
    Undefined = 0,
    User = 1,
    Admin = 2,
}