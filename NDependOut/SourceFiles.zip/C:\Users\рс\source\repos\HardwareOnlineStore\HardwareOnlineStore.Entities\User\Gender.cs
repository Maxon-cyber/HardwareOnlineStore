﻿namespace HardwareOnlineStore.Entities.User;

public enum Gender
{
    Default = 0,
    Man = 1,
    Woman = 2
}