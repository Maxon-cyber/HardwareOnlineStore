﻿global using HardwareOnlineStore.DataAccess.Providers.Relational.Implementations.SqlServer;
global using HardwareOnlineStore.DataAccess.Providers.Relational.Models;
global using HardwareOnlineStore.DataAccess.Repositories.Relational.Abstractions;
global using HardwareOnlineStore.Entities.Order;
global using HardwareOnlineStore.Entities.Product;
global using HardwareOnlineStore.Entities.User;