﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HardwareOnlineStore.Services.Entity.SqlServerService.DataProcessing;

public enum TypeOfCommand
{
    Insert = 0,
    Update = 1,
    Delete = 2
}