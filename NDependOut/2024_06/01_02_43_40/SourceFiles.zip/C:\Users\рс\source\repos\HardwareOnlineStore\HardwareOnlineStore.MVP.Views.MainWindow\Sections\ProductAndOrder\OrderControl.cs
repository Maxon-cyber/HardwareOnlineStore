﻿namespace HardwareOnlineStore.MVP.Views.MainWindow.Sections.ProductAndOrder;

public sealed partial class OrderControl : UserControl
{
    public OrderControl()
    {
        InitializeComponent();
    }
}