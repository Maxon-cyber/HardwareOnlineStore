﻿global using HardwareOnlineStore.Services.Utilities.Logger.File;
global using System.Collections.Immutable;
global using System.Data;
global using HardwareOnlineStore.Services.Entity.Contracts;
global using HardwareOnlineStore.DataAccess.Providers.Relational.Models;
global using HardwareOnlineStore.DataAccess.Repositories.Relational.SqlServer.Queries;